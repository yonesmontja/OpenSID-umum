<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<ul>
          </li>
        <li class="separator">|</li>

   	  <li>
          </li>
        <li class="separator">|</li>
   	  <li>

      </li>
   	  <li>

      </li>

</ul>
