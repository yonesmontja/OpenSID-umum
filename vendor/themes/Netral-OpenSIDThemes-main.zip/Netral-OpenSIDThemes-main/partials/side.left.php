<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="contentfront nobig">
<div class="contentfront_feature">
</div>
</div>

<div class="contentfront nobig">
<div class="contentfront_feature">
</div>
</div>

<div class="contentfront nobig">
<div class="contentfront_feature">
</div>
</div>

<div class="contentfront nobig">
<div class="contentfront_feature">
</div>
</div>
