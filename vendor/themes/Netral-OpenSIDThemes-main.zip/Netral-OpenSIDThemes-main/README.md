## Baca [Petunjuk Instalasi](https://github.com/teguhsaint/Netral-OpenSIDThemes/blob/main/README.md#instalasi) 


# Netral-OpenSIDThemes
![tes](https://user-images.githubusercontent.com/75825300/120944155-2d403280-c75d-11eb-9fc7-e644db0b5377.png)


## Tentang Netral Themes
- Designer : Teguh Saint 
- Warna / Color : Blue, White,  Green
- Icon : Fontawesome 6

## Fitur
- Tersedia Lapak

## Instalasi

- Download Tema [Disini]( https://github.com/teguhsaint/Netral-OpenSIDThemes/archive/refs/heads/main.zip
)
- Extract File
- Setelah ter Extract, buat folder baru didalam folder themes, namai "netral" tanpa tanda kutip.
- Copy File yang sudah diExtract, lalu pastekan pada direktori tema pada direktori Themes > netral
- Masuk / login ke dashboar admin. Contoh ke www.websitedesakamu.id/index.php/siteman
- Masukkan username dan password, setelah itu login
- pada menu kiri terdapat menu pengaturan > aplikasi > scroll kebawah dan pilih tema netral

## Cara Edit Lapak Warga
- ### Edit File Json Dan Peletakan Gambar

  - Letakkan gambar lapak pada folder themes > netral > assets > lapak > letakkan disini.
  - Setelah itu masuk ke direktori themes > netral > partials.
  - cari file bernama "lapak.json"
  - tambah, edit, delete atau copy baris yang tersedia.
  - sesuaikan nama produk, nama gambar ( sesuaikan dengan nama file gambar, dari nama sampai extensi gambar .jpg .png ), nomor penjual dll.
  
- ##Peletakan Gambar Lapak

## Kontribusi
- Jika anda menemukan bug atau sesuatu yang harus diperbaiki. Maka beritahu kami pada Tab [Issue](https://github.com/teguhsaint/Netral-OpenSIDThemes/issues)
