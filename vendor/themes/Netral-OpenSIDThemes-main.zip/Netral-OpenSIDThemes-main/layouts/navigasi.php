<aside class="main-sidebar sidebar-light-primary shadow" style="position: fixed">
    <!-- Brand Logo -->

    <div class=" brand-link" style="border-bottom: 2px solid #eee;">
      <div class="caraku">
      
      <span class="brand-text font-weight text-dark" style="font-size: 20px">SISDESA</span>
      </div>
    </div>

    <!-- Sidebar -->
     <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
     

      <!-- Sidebar Menu -->
      <nav class="mt-2">

        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

            <li class="nav-item mb-3">
                <a href="index.php?p=home" class="nav-link">
                     <i class="nav-icon fal fa-home"></i>
                  <p>Beranda</p>
                </a>
            </li>

          <li class="nav-item menu-open mb-3">
            <a href="#" class="nav-link mytextLigth">
             <i class="nav-icon fal fa-book-open"></i>
              <p>Surat Desa   <i class="right fal fa-angle-right"></i></p>
              
            </a>

            <ul class="nav nav-treeview" id="nav">
               <li class="nav-item" style="display: none">
                <a href="index.php?p=notice" class="nav-link ">
                  <i class="far fa-bell nav-icon"></i>
                   <p> Permohonan Surat  
          </p><div class="badge bg-warning">1</div><p></p>
                </a>
              </li>

              <li class="nav-item">
                <a href="index.php?p=suratpage" class="nav-link">
                    <i class="far fa-edit nav-icon"></i>
                  <p>Buat Surat</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?p=suratkeluar" class="nav-link">
                    <i class="fal fa-book nav-icon"></i>
                  <p>Surat Yang Keluar</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item menu-open mb-3">
            <a href="#" class="nav-link">
             <i class="nav-icon fal fa-chart-bar"></i>
              <p>Data Penduduk <i class="right fal fa-angle-right"></i></p>
                
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item kanan">
                <a href="index.php?p=tampilpnd" class="nav-link">
                 <i class="nav-icon fal fa-database"></i>
                  <p>Lihat Data</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="index.php?p=tambahpnd" class="nav-link">
                   <i class="nav-icon fal fa-plus-square"></i>
                  <p>Tambah Data</p>
                </a>
              </li>
            </ul>

          </li>

          <li class="nav-item">
                <a href="index.php?p=datamaster" class="nav-link">
                     <i class="nav-icon fal fa-cog"></i>
                  <p>Data Master</p>
                </a>
          </li>
          <li class="nav-item">
                <a href="#" class="nav-link">
                     <i class="nav-icon fal fa-info-circle"></i>
                  <p>Tentang Aplikasi</p>
                </a>
          </li>

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>